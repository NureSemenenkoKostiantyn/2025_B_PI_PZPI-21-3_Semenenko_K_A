package com.pawconnect.backend.common.enums;

public enum SwipeDecision {
    LIKE,
    PASS
}