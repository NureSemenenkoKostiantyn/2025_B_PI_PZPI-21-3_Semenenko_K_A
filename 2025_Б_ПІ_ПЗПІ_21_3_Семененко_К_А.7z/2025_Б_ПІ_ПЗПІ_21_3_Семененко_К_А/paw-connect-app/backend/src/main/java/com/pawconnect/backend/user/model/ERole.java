package com.pawconnect.backend.user.model;

public enum ERole {
    ROLE_USER,
    ROLE_PREMIUM,
    ROLE_MODERATOR,
    ROLE_ADMIN
}
