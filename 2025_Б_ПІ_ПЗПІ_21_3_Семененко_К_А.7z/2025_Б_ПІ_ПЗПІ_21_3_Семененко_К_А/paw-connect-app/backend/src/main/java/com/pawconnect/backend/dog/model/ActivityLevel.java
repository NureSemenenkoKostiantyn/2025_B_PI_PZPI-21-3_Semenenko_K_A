package com.pawconnect.backend.dog.model;

public enum ActivityLevel {
    LOW, MEDIUM, HIGH
}
