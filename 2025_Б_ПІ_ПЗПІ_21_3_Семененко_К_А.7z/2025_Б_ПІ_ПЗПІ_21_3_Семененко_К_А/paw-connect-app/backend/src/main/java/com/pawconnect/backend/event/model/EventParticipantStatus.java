package com.pawconnect.backend.event.model;

public enum EventParticipantStatus {
    GOING,
    INTERESTED
}
