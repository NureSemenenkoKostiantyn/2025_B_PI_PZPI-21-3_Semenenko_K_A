package com.pawconnect.backend.dog.model;

public enum DogGender {
    MALE, FEMALE
}
