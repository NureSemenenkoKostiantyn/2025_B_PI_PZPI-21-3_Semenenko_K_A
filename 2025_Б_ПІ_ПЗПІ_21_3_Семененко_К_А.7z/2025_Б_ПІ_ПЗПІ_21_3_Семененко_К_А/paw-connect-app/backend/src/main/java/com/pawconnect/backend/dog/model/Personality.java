package com.pawconnect.backend.dog.model;

public enum Personality {
    PLAYFUL, CALM, SHY, FRIENDLY, PROTECTIVE, INDEPENDENT
}
