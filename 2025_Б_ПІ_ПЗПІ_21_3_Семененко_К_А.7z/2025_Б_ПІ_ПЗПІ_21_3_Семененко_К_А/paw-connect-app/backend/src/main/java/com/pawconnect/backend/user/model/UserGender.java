package com.pawconnect.backend.user.model;

public enum UserGender {
    MALE, FEMALE, UNKNOWN
}
