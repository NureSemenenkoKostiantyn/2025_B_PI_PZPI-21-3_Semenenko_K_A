package com.pawconnect.backend.dog.model;

public enum DogSize {
    SMALL,
    MEDIUM,
    LARGE,
    GIANT
}
