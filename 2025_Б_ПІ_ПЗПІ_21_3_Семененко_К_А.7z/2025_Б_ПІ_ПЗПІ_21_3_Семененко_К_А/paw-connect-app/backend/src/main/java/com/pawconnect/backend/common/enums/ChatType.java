package com.pawconnect.backend.common.enums;

public enum ChatType {
    PRIVATE,
    GROUP
}